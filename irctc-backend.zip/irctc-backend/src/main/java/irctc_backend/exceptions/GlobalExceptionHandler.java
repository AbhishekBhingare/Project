package irctc_backend.exceptions;

import irctc_backend.dto.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

@RestControllerAdvice
public class GlobalExceptionHandler {

//    pure project ke liye handle exception
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<ErrorResponse> handleNoSuchExceptioin(NoSuchElementException exception){
        ErrorResponse response = new ErrorResponse("Not Found "+exception.getMessage(),"404",false);

        ResponseEntity<ErrorResponse> responseResponseEntity = new ResponseEntity<ErrorResponse>(response, HttpStatus.NOT_FOUND);

        return responseResponseEntity;
    }


    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFound(ResourceNotFoundException exception){
        ErrorResponse response = new ErrorResponse(exception.getMessage(),"404",false);

        ResponseEntity<ErrorResponse> responseResponseEntity = new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        return responseResponseEntity;
    }

    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleSQLIntegrityConstraintViolationException(SQLIntegrityConstraintViolationException exception){
        String message = exception.getMessage().contains("Duplicate entry")? "You are trying to insert code that are already exits": exception.getMessage();

        ErrorResponse response = new ErrorResponse(message,"400",false);

        ResponseEntity<ErrorResponse> responseResponseEntity = new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        return responseResponseEntity;
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,String>> handleMethodArgumentNotValidException(MethodArgumentNotValidException methodArgumentNotValidException){

        Map<String, String> erroResponse = new HashMap<>();
        methodArgumentNotValidException.getBindingResult().getAllErrors().forEach(error ->{

            System.out.println("in method argument not valid exception ");
            String field = ((FieldError)error).getField();
            String errorMessage = error.getDefaultMessage();
            erroResponse.put(field,errorMessage);

        });
        ResponseEntity<Map<String, String>> error = new ResponseEntity<>(erroResponse, HttpStatus.BAD_REQUEST);
        return error;
    }

}
