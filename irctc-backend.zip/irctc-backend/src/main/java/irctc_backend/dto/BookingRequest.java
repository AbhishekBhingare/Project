package irctc_backend.dto;

import irctc_backend.entity.CoachType;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingRequest {

    private Long userId;
    private Long trainScheduleId;
    private Long trainId;
    private Long sourceStationId;
    private Long destinationStationId;
    private LocalDate journeyDate;
    private CoachType coachType;
    private List<BookingPassengerDto> passengers;

}
