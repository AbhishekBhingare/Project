package irctc_backend.dto;

import irctc_backend.entity.BookingPassenger;
import irctc_backend.entity.BookingStatus;
import irctc_backend.entity.PaymentStaus;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Setter
@Getter
public class BookingResponce {

    private Long bookingId;
    private LocalDate journeyDate;
    private LocalTime departureTime;
    private LocalTime arrivalTime;
    private StationDTO sourceStation;
    private StationDTO destinationStation;
    private String pnr;
    private BigDecimal totalFare;
    private BookingStatus bookingStatus;
    private PaymentStaus paymentStaus;
    private List<BookingPassengerDto> passenger;


}
