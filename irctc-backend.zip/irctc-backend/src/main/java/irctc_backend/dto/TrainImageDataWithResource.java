package irctc_backend.dto;

import irctc_backend.entity.TrainImage;
import org.springframework.core.io.Resource;

public record TrainImageDataWithResource(
        TrainImage trainImage,
        Resource resource
) {
}
