package irctc_backend.dto;

import irctc_backend.entity.CoachType;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AvailableTrainResponce {

    private Long trainId;
    private String trainName;
    private String trainNumber;
    private LocalTime departureTime;
    private LocalTime arrivalTime;
    private Map<CoachType, Integer> seatsAvailable;
    private Map<CoachType, Double> priceByCoachType;
    private LocalDate scheduleDate;
    private Long trainScheduleId;
}
