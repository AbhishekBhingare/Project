package irctc_backend.dto;

public record JwtResponse(
        String token,
        UserDto user
) {
}
