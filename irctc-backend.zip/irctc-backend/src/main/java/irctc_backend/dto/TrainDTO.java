package irctc_backend.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.format.DecimalStyle;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TrainDTO {


    private Long id;

    @Schema(description = "Train Number", example = "12345", required = true)
    @NotEmpty(message = "train number is required")
    @Size(min = 2,max = 20,message = "train number length should be between 2-20")
    @Pattern(regexp = "^\\d+$", message = "Invalid No. Train No. contain only number")
    @Id
    private String number;

    @Schema(description = "Train Name", example = "LKO - DELHI Intercity", required = true)
    @Pattern(regexp = "^[A-Za-z][A-Za-z -]*[A-Za-z]$", message = "Invalid Train name, letter, spaces and hypens are allow")
    private String name;


    private Integer totalDistance;
    private StationDTO sourceStation;
    private StationDTO destinationStation;

}