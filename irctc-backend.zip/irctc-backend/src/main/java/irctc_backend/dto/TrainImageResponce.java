package irctc_backend.dto;

import irctc_backend.entity.TrainImage;

import java.time.LocalDateTime;

public record TrainImageResponce(
        Long id,
        String fileName,
        String fileType,
        String url,
        long size,
        LocalDateTime uploadTime
) {

    public static TrainImageResponce from(TrainImage image, String baseUrl, Long trainNo) {
        return new TrainImageResponce(
                image.getId(),
                image.getFileName(),
                image.getFileType(),
                baseUrl + "/trains/" + trainNo+"/image",
                image.getSize(),
                image.getUploadTime()
        );
    }

}