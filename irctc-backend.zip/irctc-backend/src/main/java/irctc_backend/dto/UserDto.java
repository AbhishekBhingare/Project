package irctc_backend.dto;

import irctc_backend.entity.Role;
import lombok.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDto {
    private Long id;
    private String name;
    private String email;
    private String password;
    private String phone;
    private LocalDateTime createdAt;

    private List<RoleDto> roles = new ArrayList<>();
}
