package irctc_backend.dto;

import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainScheduleDto {
    private Long Id;
    private Long trainId;
    private LocalDate runDate;
    private Integer availableSeats;

}
