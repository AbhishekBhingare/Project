package irctc_backend.controller.admin;

import irctc_backend.config.AppConstant;
import irctc_backend.dto.PageResponse;
import irctc_backend.dto.StationDTO;
import irctc_backend.service.StationSevice;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin/stations")
public class StationController {

    private StationSevice stationSevice;

    public StationController(StationSevice stationSevice) {
        this.stationSevice = stationSevice;
    }

    //    create station
    @PostMapping
    public ResponseEntity<StationDTO> create (
            @Valid @RequestBody StationDTO stationDto
    ){
        StationDTO dto = stationSevice.create(stationDto);
        return  new ResponseEntity<> (dto,HttpStatus.CREATED);
    }

    @GetMapping
    public PageResponse<StationDTO> listStation(
            @RequestParam(value = "page", defaultValue = AppConstant.DEFAULT_PAGE) int page,
            @RequestParam(value = "size", defaultValue = AppConstant.DEFAULT_PAGE_SIZE) int size,
            @RequestParam(value = "sortBy", defaultValue = "name") String sortBy,
            @RequestParam(value = "sortDir", defaultValue = "asc") String sortDir
    ){
        PageResponse<StationDTO> stationDTOPageResponse = stationSevice.listStaion(
                page,
                size,
                sortBy,
                sortDir
        );
        return stationDTOPageResponse;
    }

    @GetMapping("/{id}")
    public StationDTO getById(
            @PathVariable Long id
    ){
        StationDTO stationDTO = stationSevice.getById(id);
        return stationDTO;
    }


    @PutMapping("/{id}")
    public StationDTO update(
            @RequestBody StationDTO stationDTO,
            @PathVariable Long id
    ){
        StationDTO updatedStaionDTO1= stationSevice.update(id,stationDTO);
        return updatedStaionDTO1;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        stationSevice.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}
