package irctc_backend.controller.admin;

import irctc_backend.dto.TrainRouteDto;
import irctc_backend.service.TrainRouteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/train-routes")
public class TrainRouteController {

    private TrainRouteService trainRouteService;

    public TrainRouteController(TrainRouteService trainRouteService) {
        this.trainRouteService = trainRouteService;
    }

    @PostMapping
    public ResponseEntity<TrainRouteDto> createTrainRoute(
            @RequestBody TrainRouteDto trainRouteDto
    ){
        TrainRouteDto createRoute = trainRouteService.addRoute(trainRouteDto);
        return  ResponseEntity.status(201).body(createRoute);
    }

//    list train route by train id
    @GetMapping("/train/{id}")
    public ResponseEntity<List<TrainRouteDto>> getRoutesByTrain(@PathVariable Long id){
        List<TrainRouteDto> trainRouteDto = trainRouteService.getRoutesByTrain(id);
        return ResponseEntity.ok(trainRouteDto);
    }
//    update train route
    @PutMapping("/train/{trainId}")
    public  ResponseEntity<TrainRouteDto> updateTrainRoute(
            @PathVariable Long id,
            @RequestBody TrainRouteDto trainRouteDto
    ){
        TrainRouteDto trainRouteDto1 = trainRouteService.update(id,trainRouteDto);
        return ResponseEntity.ok(trainRouteDto1);

    }

//    delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrainRoute(@PathVariable Long id){
        trainRouteService.deleteRoute(id);
        return ResponseEntity.noContent().build();
    }

}
