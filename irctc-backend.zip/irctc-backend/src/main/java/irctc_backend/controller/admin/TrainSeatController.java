package irctc_backend.controller.admin;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import irctc_backend.dto.TrainSeatDto;
import irctc_backend.service.TrainSeatService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/train-seats")
public class TrainSeatController {

    private TrainSeatService trainSeatService;

    public TrainSeatController(TrainSeatService trainSeatService) {
        this.trainSeatService = trainSeatService;
    }

    @PostMapping
    public ResponseEntity<TrainSeatDto> createSeat(
            @RequestBody TrainSeatDto trainSeatDto
    ){
        TrainSeatDto createdSeat = trainSeatService.createTrainSeatInto(trainSeatDto);
        return ResponseEntity.status(201).body(createdSeat);
    }




    @Operation(
            summary = "Get train seats of train schedule",
            description = "This api get train seats[coaches] of train schedule"
    )
    @GetMapping("/schedule/{scheduleId}")
    public ResponseEntity<List<TrainSeatDto>> getSeatByScheduleId(
            @Parameter(description = "Id of Train schedule to get details") @PathVariable Long scheduleId
    ){
        List<TrainSeatDto> seat = trainSeatService.getSeatInfoByTrainScheduleId(scheduleId);
        return ResponseEntity.ok(seat);

    }

    @DeleteMapping("{seatId}")
    public ResponseEntity<Void> deleteTrainSeat(
            @PathVariable Long seatId
    ){
        trainSeatService.deleteTrainSeatInfo(seatId);
        return ResponseEntity.noContent().build();

    }

    @PutMapping("/{seatId}")
    public ResponseEntity<TrainSeatDto> updateTrainSeat(
            @PathVariable Long seatId,
            @RequestBody TrainSeatDto trainSeatDto
    ){
        TrainSeatDto updateTrainSeat = trainSeatService.updateTrainSeatInfo(seatId,trainSeatDto);
        return ResponseEntity.ok(updateTrainSeat);
    }


}
