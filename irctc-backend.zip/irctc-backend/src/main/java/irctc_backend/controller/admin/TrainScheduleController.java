package irctc_backend.controller.admin;

import irctc_backend.dto.TrainScheduleDto;
import irctc_backend.service.TrainScheduleService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("admin/train-schedules")
public class TrainScheduleController {

    private TrainScheduleService trainScheduleService;

    public TrainScheduleController(TrainScheduleService trainScheduleService) {
        this.trainScheduleService = trainScheduleService;
    }

    @PostMapping
    public ResponseEntity<TrainScheduleDto> create(
            @RequestBody TrainScheduleDto trainScheduleDto
    ){
        TrainScheduleDto createdTrainScheduleDto1 =  trainScheduleService.createSchedule(trainScheduleDto);
//        return ResponseEntity.status(HttpStatus.CREATED).body(createdTrainScheduleDto1);
        return new ResponseEntity<>(createdTrainScheduleDto1,HttpStatus.CREATED);
    }


    @GetMapping("/train/{trainId}")
    public List<TrainScheduleDto> getTrainScheduleByTrainId(@PathVariable Long trainId){
       return trainScheduleService.getTrainScheduleByTrainId(trainId);
    }

    @PutMapping("/{trainScheduleId}")
    public ResponseEntity<TrainScheduleDto> updateTrainSchedule(@PathVariable Long trainScheduleId,
                                                                @RequestBody TrainScheduleDto trainScheduleDto){
        TrainScheduleDto updatedTrainSchedule = trainScheduleService.updateTrainSchedule(trainScheduleId,trainScheduleDto);
        return ResponseEntity.ok(updatedTrainSchedule);

    }





}
