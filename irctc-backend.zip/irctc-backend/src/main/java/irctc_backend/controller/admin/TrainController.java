package irctc_backend.controller.admin;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import irctc_backend.dto.TrainDTO;
import irctc_backend.service.TrainService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/trains")
public class TrainController {

    private TrainService trainService;

    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }

    //    create
    @Operation(
            summary = "Create Train",
            description = "This api create new Trains"
    )
    @PostMapping
    public ResponseEntity<TrainDTO> createTrain(
            @RequestBody TrainDTO trainDTO
    ){
//        System.out.println(trainDTO.getNumber());
//        System.out.println(trainDTO.getName());
//        System.out.println(trainDTO.getSourceStation().getId());

        return new ResponseEntity<>(trainService.createTrain(trainDTO), HttpStatus.CREATED);

    }

//    list
    @Operation(
            summary = "get all trains",
            description = "This api is used to get all train"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "request succesful"),
            @ApiResponse(responseCode = "404", description = "Train not found")
    })
    @GetMapping
    public List<TrainDTO> getTrains(){
        return trainService.getAllTrains();
    }

//      get detail
    @Operation(
            summary = "Get train by Id",
            description = "This api get Train by id"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "request successful"),
            @ApiResponse(responseCode = "404", description = "Train not found"),
            @ApiResponse(responseCode = "500", description = "Server error")
    })
    @GetMapping("/{id}")
    public ResponseEntity<TrainDTO> getById(
            @Parameter(description = "Id of Train") @PathVariable Long id){
        return new ResponseEntity<>(trainService.getTrainById(id),HttpStatus.OK);
    }

//    update
    @Operation(
            summary = "Update Train",
            description = "This api update train"
    )
    @PutMapping("/{id}")
    public ResponseEntity<TrainDTO> update(@PathVariable Long id, @RequestBody TrainDTO trainDTO){

        return new ResponseEntity<>(trainService.update(id,trainDTO),HttpStatus.OK);

    }


//    delete train
    @Operation(
            summary = "Delete Train",
            description = "This api delete train by train id"
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        trainService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
