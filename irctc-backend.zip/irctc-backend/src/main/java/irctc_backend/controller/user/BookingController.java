package irctc_backend.controller.user;


import irctc_backend.dto.BookingRequest;
import irctc_backend.dto.BookingResponce;
import irctc_backend.service.BookingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user/booking")
public class BookingController {

    private BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    //    create bookings
    @PostMapping
    public ResponseEntity<BookingResponce> createBookings(
            @RequestBody BookingRequest bookingRequest
    ){
        BookingResponce bookingResponce = this.bookingService.createBookings(bookingRequest);
        return new ResponseEntity<>(bookingResponce, HttpStatus.CREATED);

    }

}
