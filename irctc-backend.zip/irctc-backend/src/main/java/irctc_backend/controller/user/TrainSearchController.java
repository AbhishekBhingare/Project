package irctc_backend.controller.user;

import irctc_backend.dto.AvailableTrainResponce;
import irctc_backend.dto.UserTrainSearchRequest;
import irctc_backend.service.TrainService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/trains")
public class TrainSearchController {

    private TrainService trainService;

    public TrainSearchController(TrainService trainService) {
        this.trainService = trainService;
    }

    //    search train
    @PostMapping("/search")
    public ResponseEntity<List<AvailableTrainResponce>> searchTrain(
            @RequestBody UserTrainSearchRequest userTrainSearchRequest
            ){
        System.out.println("Search Request: " + userTrainSearchRequest);


        List<AvailableTrainResponce> availableTrainResponces = trainService.userTrainSearch(userTrainSearchRequest);
        System.out.println("Trains found: " + availableTrainResponces.size());

        return new ResponseEntity<>(availableTrainResponces, HttpStatus.OK);
    }
}
