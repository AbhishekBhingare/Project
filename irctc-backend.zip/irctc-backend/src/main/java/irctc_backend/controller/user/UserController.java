package irctc_backend.controller.user;

public class UserController {

}
