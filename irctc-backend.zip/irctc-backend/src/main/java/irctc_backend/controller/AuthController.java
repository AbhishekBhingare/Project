package irctc_backend.controller;

import irctc_backend.config.security.JwtHelper;
import irctc_backend.dto.ErrorResponse;
import irctc_backend.dto.JwtResponse;
import irctc_backend.dto.LoginRequest;
import irctc_backend.dto.UserDto;
import irctc_backend.entity.User;
import irctc_backend.repository.UserRepo;
import irctc_backend.service.UserService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private AuthenticationManager authenticationManager;
    private UserDetailsService userDetailsService;
    private JwtHelper jwtHelper;
    private UserService userService;
    private UserRepo userRepo;
    private ModelMapper modelMapper;

    public AuthController(AuthenticationManager authenticationManager, JwtHelper jwtHelper, ModelMapper modelMapper, UserDetailsService userDetailsService, UserRepo userRepo, UserService userService) {
        this.authenticationManager = authenticationManager;
        this.jwtHelper = jwtHelper;
        this.modelMapper = modelMapper;
        this.userDetailsService = userDetailsService;
        this.userRepo = userRepo;
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest loginRequest
    ) {
        ErrorResponse errorResponse;
        try {

            UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(loginRequest.username(), loginRequest.password());
            this.authenticationManager.authenticate(authentication);

//            generate token
            UserDetails userDetails = userDetailsService.loadUserByUsername(loginRequest.username());
            String token = this.jwtHelper.generateToken(userDetails);
            User user = userRepo.findByEmail(loginRequest.username()).get();

            JwtResponse jwtResponse = new JwtResponse(
                    token,
                    modelMapper.map(user,UserDto.class)
            );
            return new ResponseEntity<>(jwtResponse, HttpStatus.OK);


        } catch (BadCredentialsException ex) {
            System.out.println("Invalid Credentials");
            errorResponse = new ErrorResponse(
                    "User name and password you entered is incorect",
                    "403",
                    false
            );
        }

        return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
    }


    @PostMapping("/register")
    public ResponseEntity<?> registerUser(
            @Valid @RequestBody UserDto userDto
            ){
        UserDto userDto1 = userService.registerUser(userDto);
        return new ResponseEntity<>(userDto1,HttpStatus.CREATED);
    }

    @GetMapping("/test")
    @PreAuthorize("hasRole('NORMAL')")
    public String test(){
        return "test";
    }


}
