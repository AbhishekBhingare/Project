package irctc_backend.service;

import irctc_backend.dto.AvailableTrainResponce;
import irctc_backend.dto.TrainDTO;
import irctc_backend.dto.UserTrainSearchRequest;
import irctc_backend.entity.Train;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface TrainService {


    //    create train
    public TrainDTO createTrain(TrainDTO trainDTO);

    //    list Train
    public List<TrainDTO> getAllTrains();

    //    get train by id
    public TrainDTO getTrainById(Long id);

//    update train
    public TrainDTO update(Long id,TrainDTO trainDTO);

//    delete train
    public  void delete (Long id);

//    search train for booking
    List<AvailableTrainResponce> userTrainSearch(UserTrainSearchRequest request);
}
