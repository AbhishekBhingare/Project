package irctc_backend.service;

import irctc_backend.dto.PageResponse;
import irctc_backend.dto.StationDTO;
import org.springframework.http.ResponseEntity;


public interface StationSevice {
    StationDTO create(StationDTO stationDto);
    PageResponse<StationDTO> listStaion(int page, int size, String sortBy, String sortDir);
    StationDTO getById(Long id);
    StationDTO update(Long id,StationDTO stationDTO);
    void delete(Long id);
}
