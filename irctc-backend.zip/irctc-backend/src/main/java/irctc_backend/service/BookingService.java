package irctc_backend.service;

import irctc_backend.dto.BookingRequest;
import irctc_backend.dto.BookingResponce;

public interface BookingService {
    BookingResponce createBookings(BookingRequest bookingRequest);

}
