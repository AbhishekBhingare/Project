package irctc_backend.service.impl;

import irctc_backend.dto.UserDto;
import irctc_backend.entity.Role;
import irctc_backend.entity.User;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.RoleRepo;
import irctc_backend.repository.UserRepo;
import irctc_backend.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;

@Service
public class UserServiceImpl implements UserService {

    private UserRepo userRepo;
    private RoleRepo roleRepo;
    private ModelMapper modelMapper;
    private PasswordEncoder passwordEncoder;

    public UserServiceImpl(ModelMapper modelMapper, PasswordEncoder passwordEncoder, RoleRepo roleRepo, UserRepo userRepo) {
        this.modelMapper = modelMapper;
        this.passwordEncoder = passwordEncoder;
        this.roleRepo = roleRepo;
        this.userRepo = userRepo;
    }

    @Override
    public UserDto registerUser(UserDto userDto) {


        User user = modelMapper.map(userDto, User.class);
        Role role = roleRepo.findByName("ROLE_NORMAL").orElseThrow(()-> new ResourceNotFoundException("Contact support Team as user not found for ROLE_USER"));
        user.getRoles().add(role);
        System.out.println(user.getPassword());
        System.out.println(user.getName());
        System.out.println(user.getEmail());
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setCreatedAt(LocalDateTime.now());
//        you have to add user role in database

        User savedUsesr = userRepo.save(user);
        return modelMapper.map(savedUsesr,UserDto.class);
    }
}
