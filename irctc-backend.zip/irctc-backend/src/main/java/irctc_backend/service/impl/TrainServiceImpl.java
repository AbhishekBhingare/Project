package irctc_backend.service.impl;

import irctc_backend.dto.AvailableTrainResponce;
import irctc_backend.dto.TrainDTO;
import irctc_backend.dto.UserTrainSearchRequest;
import irctc_backend.entity.*;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.StationRepository;
import irctc_backend.repository.TrainRepository;
import irctc_backend.repository.TrainRouteRepository;
import irctc_backend.repository.TrainScheduleRepository;
import irctc_backend.service.TrainService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Service
public class TrainServiceImpl implements TrainService {

    private TrainRepository trainRepository;
    private StationRepository stationRepository;
    private ModelMapper modelMapper;
    private TrainScheduleRepository trainScheduleRepository;
    private TrainRouteRepository trainRouteRepository;

    public TrainServiceImpl(ModelMapper modelMapper, TrainRouteRepository trainRouteRepository, StationRepository stationRepository, TrainRepository trainRepository, TrainScheduleRepository trainScheduleRepository) {
        this.modelMapper = modelMapper;
        this.stationRepository = stationRepository;
        this.trainRepository = trainRepository;
        this.trainScheduleRepository = trainScheduleRepository;
        this.trainRouteRepository = trainRouteRepository;
    }

    @Override
    public TrainDTO createTrain(TrainDTO trainDTO) {
        Long sid = trainDTO.getSourceStation().getId();
        Long did = trainDTO.getDestinationStation().getId();
//      check is source station and destination station is there in databasaee or not
        Station sourceStation = stationRepository.findById(sid).orElseThrow(() -> new ResourceNotFoundException("Source station not found with id: " + sid));
        Station destinationStation = stationRepository.findById(did).orElseThrow(() -> new ResourceNotFoundException("destingation station not found with id: " + did));
//        if present map trainDTO to train
        Train train = modelMapper.map(trainDTO, Train.class);
//        and set
        train.setSourceStation(sourceStation);
        train.setDestinationStation(destinationStation);

        Train savedtrain = trainRepository.save(train);
        return modelMapper.map(savedtrain, TrainDTO.class);
    }

    @Override
    public List<TrainDTO> getAllTrains() {
        List<Train> all = trainRepository.findAll();
//        for(Train train: all){
//            System.out.println(train);
//            System.out.println(train.getName());
//        }
        return all.stream().map((train -> modelMapper.map(train, TrainDTO.class))).toList();
    }

    @Override
    public TrainDTO getTrainById(Long id) {
        Train train = trainRepository.findById(id).orElseThrow((() -> new ResourceNotFoundException("train not found with id: " + id)));
        return modelMapper.map(train, TrainDTO.class);
    }

    @Override
    public TrainDTO update(Long id, TrainDTO trainDTO) {
        Train existingTrain = trainRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("train not found with id: "+id));
        existingTrain.setName(trainDTO.getName());
        existingTrain.setNumber(trainDTO.getNumber());
        existingTrain.setTotalDistance(trainDTO.getTotalDistance());
//        fetch source and destination station
        Station sourceStation = stationRepository.findById(trainDTO.getSourceStation().getId()).orElseThrow(()->new ResourceNotFoundException("source station not found wit id: "+trainDTO.getSourceStation().getId()));
        Station destinationStation = stationRepository.findById(trainDTO.getDestinationStation().getId()).orElseThrow(()-> new ResourceNotFoundException("Destination statioin not found with id: "+trainDTO.getDestinationStation().getId()));
        existingTrain.setSourceStation(sourceStation);
        existingTrain.setDestinationStation(destinationStation);
        Train updatedTrain = trainRepository.save(existingTrain);
        return modelMapper.map(updatedTrain,TrainDTO.class);
    }

    @Override
    public void delete(Long id) {
        Train existingTrain = trainRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Train not found to delete with id: "+id));
        trainRepository.delete(existingTrain);

    }





//    ---------------------orignal search code start--------------------

//
//public List<AvailableTrainResponce> userTrainSearch(UserTrainSearchRequest request) {
//// Fetch trains from repository with source and destination
//    List<Train> matchedTrains = this.trainRepository.findTrainBySourceAndDestination(
//            request.getSourceStationId(), request.getDestinationStationId());
//
//// Use stream to filter valid trains directly
//    List<AvailableTrainResponce> responseList = matchedTrains.stream()
//            .filter(train -> {
//                // Find source and destination station orders in a single loop
//                Integer sourceStationOrder = null;
//                Integer destinationStationOrder = null;
//
//                for (TrainRoute trainRoute : train.getRoutes()) {
//                    if (trainRoute.getStation().getId().equals(request.getSourceStationId())) {
//                        sourceStationOrder = trainRoute.getStationOrder();
//                    } else if (trainRoute.getStation().getId().equals(request.getDestinationStationId())) {
//                        destinationStationOrder = trainRoute.getStationOrder();
//                    }
//
//                    // Early exit if both station orders are found
//                    if (sourceStationOrder != null && destinationStationOrder != null) {
//                        break;
//                    }
//                }
//
//                // Check for station order validity and the schedule date condition
//                boolean validOrder = sourceStationOrder != null && destinationStationOrder != null &&
//                        sourceStationOrder < destinationStationOrder;
//
//                boolean runOnThatDay = train.getTrainSchedules().stream()
//                        .anyMatch(schedule -> schedule.getRunDate().equals(request.getJourneyDate()));
//
//                return validOrder && runOnThatDay;
//            })
//            .map(train -> {
//                // Find the matching schedule for the journey date
//                TrainSchedule trainSchedule = train.getTrainSchedules().stream()
//                        .filter(sch -> sch.getRunDate().equals(request.getJourneyDate()))
//                        .findFirst().orElse(null);
//
//                if (trainSchedule == null) {
//                    return null;  // Skip if there's no matching schedule
//                }
//
//                // Find the source route for the train
//                TrainRoute sourceRoute = train.getRoutes().stream()
//                        .filter(route -> route.getStation().getId().equals(request.getSourceStationId()))
//                        .findFirst().orElse(null);
//
//                if (sourceRoute == null) {
//                    return null;  // Skip if there's no source route
//                }
//
//                // Map seat types and prices
//                Map<CoachType, Integer> seatMap = new HashMap<>();
//                Map<CoachType, Double> priceMap = new HashMap<>();
//
//                System.out.println(trainSchedule.getTrainSeats());
////                System.out.println(trainSchedule.getTrainSeats().getFirst().getAvailableSeats()+"printing price of seat");
////                System.out.println(trainSchedule.getTrainSeats().getFirst().getPrice()+"printing of available seat");
////
//
//
//
//
////                System.out.println("---------------------------");
//                trainSchedule.getTrainSeats().forEach(trainSeat -> {
//                    seatMap.merge(trainSeat.getCoachType(), trainSeat.getAvailableSeats(), Integer::sum);
//                    priceMap.putIfAbsent(trainSeat.getCoachType(), trainSeat.getPrice());
////                    System.out.println(trainSeat.getPrice()+"printing price of seat");
////                    System.out.println(trainSeat.getAvailableSeats()+"printing of available seat");
//                });
////                System.out.println(seatMap);
////                System.out.println(priceMap);
//
//
//
//
//
//
//
//                // Build the response for the valid train
//                return AvailableTrainResponce.builder()
//                        .trainId(train.getId())
//                        .trainNumber(train.getNumber())
//                        .trainName(train.getName())
//                        .departureTime(sourceRoute.getDepartureTime())
//                        .arrivalTime(sourceRoute.getArrivalTime())
//                        .seatsAvailable(seatMap)
//                        .priceByCoachType(priceMap)
//                        .scheduleDate(trainSchedule.getRunDate())
//                        .trainScheduleId(trainSchedule.getId())
//                        .build();
//            })
//            .filter(Objects::nonNull)  // Remove null responses (invalid trains)
//            .collect(Collectors.toList());  // Collect results into a list
//
//// Return the final list of valid available train responses
//    return responseList;
//}

// -------------------   orignal code search end




//    editing search code start?


public List<AvailableTrainResponce> userTrainSearch(UserTrainSearchRequest request) {
    // Fetch trains from repository with source and destination
    List<Train> matchedTrains = this.trainRepository.findTrainBySourceAndDestination(
            request.getSourceStationId(), request.getDestinationStationId());

    return matchedTrains.stream()
            .filter(train -> {
                Integer sourceOrder = null;
                Integer destOrder = null;

                for (TrainRoute route : train.getRoutes()) {
                    if (route.getStation().getId().equals(request.getSourceStationId())) {
                        sourceOrder = route.getStationOrder();
                    } else if (route.getStation().getId().equals(request.getDestinationStationId())) {
                        destOrder = route.getStationOrder();
                    }
                    if (sourceOrder != null && destOrder != null) break;
                }

                boolean validOrder = sourceOrder != null && destOrder != null && sourceOrder < destOrder;
                boolean runOnThatDay = train.getTrainSchedules().stream()
                        .anyMatch(schedule -> schedule.getRunDate().equals(request.getJourneyDate()));

                return validOrder && runOnThatDay;
            })
            .map(train -> {
                // Find schedule for the requested date
                TrainSchedule trainSchedule = train.getTrainSchedules().stream()
                        .filter(sch -> sch.getRunDate().equals(request.getJourneyDate()))
                        .findFirst().orElse(null);
                if (trainSchedule == null) return null;

                // Sort routes for safety
                List<TrainRoute> routes = new ArrayList<>(train.getRoutes());
                routes.sort(Comparator.comparingInt(TrainRoute::getStationOrder));

                // Find source & destination routes
                TrainRoute sourceRoute = routes.stream()
                        .filter(r -> r.getStation().getId().equals(request.getSourceStationId()))
                        .findFirst().orElse(null);
                TrainRoute destinationRoute = routes.stream()
                        .filter(r -> r.getStation().getId().equals(request.getDestinationStationId()))
                        .findFirst().orElse(null);
                if (sourceRoute == null || destinationRoute == null) return null;

                final int sourceOrder = sourceRoute.getStationOrder();
                final int destOrder = destinationRoute.getStationOrder();

                // ✅ Sum distances for the segment source → destination
                final int travelDistance = routes.stream()
                        .filter(r -> r.getStationOrder() > sourceOrder && r.getStationOrder() <= destOrder)
                        .mapToInt(TrainRoute::getDistanceFromSource)
                        .sum();

                // Prepare maps for seats and price
                Map<CoachType, Integer> seatMap = new HashMap<>();
                Map<CoachType, Double> priceMap = new HashMap<>();

                // Loop through each seat type in train schedule
                trainSchedule.getTrainSeats().forEach(trainSeat -> {
                    // 1️⃣ Calculate price for this segment
                    double perKmPrice = trainSeat.getPrice();  // price per km
                    double totalPrice = perKmPrice * travelDistance;
                    priceMap.put(trainSeat.getCoachType(), totalPrice);

                    // 2️⃣ Calculate seat availability dynamically
                    int totalSeats = trainSeat.getAvailableSeats();

                    // TODO: Replace 0 with actual booked seats logic if needed
                    int bookedSeats = 0;
                    int availableSeatsForSegment = totalSeats - bookedSeats;

                    // If multiple legs exist for same coach type, take the MIN
                    seatMap.merge(trainSeat.getCoachType(), availableSeatsForSegment, Math::min);

                    System.out.println("Coach: " + trainSeat.getCoachType()
                            + " | Dist: " + travelDistance
                            + " | perKm: " + perKmPrice
                            + " | Total: " + totalPrice
                            + " | SeatsAvail: " + availableSeatsForSegment);
                });

                // Build final response
                return AvailableTrainResponce.builder()
                        .trainId(train.getId())
                        .trainNumber(train.getNumber())
                        .trainName(train.getName())
                        .departureTime(sourceRoute.getDepartureTime())
                        .arrivalTime(destinationRoute.getArrivalTime())
                        .seatsAvailable(seatMap)
                        .priceByCoachType(priceMap)
                        .scheduleDate(trainSchedule.getRunDate())
                        .trainScheduleId(trainSchedule.getId())
                        .build();
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
}




//    editing search code end

}

