package irctc_backend.service.impl;

import irctc_backend.dto.BookingPassengerDto;
import irctc_backend.dto.BookingRequest;
import irctc_backend.dto.BookingResponce;
import irctc_backend.dto.StationDTO;
import irctc_backend.entity.*;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.*;
import irctc_backend.service.BookingService;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.w3c.dom.stylesheets.LinkStyle;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class BookingServiceImpl implements BookingService {

    private BookingRepository bookingRepository;
    private BookingPassengerRepository bookingPassengerRepository;
    private UserRepo userRepo;
    private TrainScheduleRepository trainScheduleRepository;
    private TrainRepository trainRepository;
    private StationRepository stationRepository;
    private ModelMapper modelMapper;
    private TrainSeatRepository trainSeatRepository;


    public BookingServiceImpl(BookingPassengerRepository bookingPassengerRepository, BookingRepository bookingRepository, ModelMapper modelMapper, StationRepository stationRepository, TrainRepository trainRepository, TrainScheduleRepository trainScheduleRepository, TrainSeatRepository trainSeatRepository, UserRepo userRepo) {
        this.bookingPassengerRepository = bookingPassengerRepository;
        this.bookingRepository = bookingRepository;
        this.modelMapper = modelMapper;
        this.stationRepository = stationRepository;
        this.trainRepository = trainRepository;
        this.trainScheduleRepository = trainScheduleRepository;
        this.trainSeatRepository = trainSeatRepository;
        this.userRepo = userRepo;
    }

    @Override
    @Transactional
    public synchronized BookingResponce createBookings(BookingRequest bookingRequest) {

        User user = this.userRepo.findById(bookingRequest.getUserId()).orElseThrow(()-> new ResourceNotFoundException("user not found with id : "+bookingRequest.getUserId()));
        TrainSchedule trainSchedule = this.trainScheduleRepository.findById(bookingRequest.getTrainScheduleId()).orElseThrow(()-> new ResourceNotFoundException("train schdeule not found id: "+bookingRequest.getTrainScheduleId()));

        Station sourceStation = stationRepository.findById(bookingRequest.getSourceStationId()).orElseThrow(()-> new ResourceNotFoundException("Source Staioin not found with id : "+bookingRequest.getSourceStationId()));
        Station destinationStation = stationRepository.findById(bookingRequest.getDestinationStationId()).orElseThrow(()-> new ResourceNotFoundException("Destination Station not found with id : "+bookingRequest.getDestinationStationId()));

//        method
        List<TrainSeat> coaches = trainSchedule.getTrainSeats();
//        it will sort coaches based on trainOrder
        coaches.sort((s1,s2)->s1.getTrainSeatOrder()- s2.getTrainSeatOrder());
        List<TrainSeat> selectedCoaches = coaches.stream().filter(coach-> coach.getCoachType()== bookingRequest.getCoachType()).toList();

//        total number of requested seats
        int totalRequestSeat = bookingRequest.getPassengers().size();


//        kis coach mai book karenge
        TrainSeat coachToBookSeat = null;
        for(TrainSeat coach : selectedCoaches){
            if(coach.isSeatAvailable(totalRequestSeat)){
                coachToBookSeat = coach;
                break;
            }
        }

        if(coachToBookSeat==null){
            throw new ResourceNotFoundException("No seats Available in this type of coach");
        }


//        book seat
        Booking booking = new Booking();
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setSourceStation(sourceStation);
        booking.setDestinationStation(destinationStation);
        booking.setTrainSchedule(trainSchedule);
        booking.setUser(user);
        booking.setCreatedAt(LocalDateTime.now());
        booking.setJourneyDate(trainSchedule.getRunDate());
        booking.setPnr(UUID.randomUUID().toString());
//        set total fare
        booking.setTotalFare(new BigDecimal(totalRequestSeat*coachToBookSeat.getPrice()));

        Payment payment = new Payment();
        payment.setAmount(booking.getTotalFare());
        payment.setPaymentMethod(null);
        payment.setPaymentStaus(null);
        payment.setPaymentStaus(PaymentStaus.NOT_PAID);
        payment.setBooking(booking);
//        set the payment
        booking.setPayment(payment);


        List<BookingPassenger> bookingPassengers = new ArrayList<>();

        for(BookingPassengerDto bookingPassengerDto : bookingRequest.getPassengers()){

            BookingPassenger passenger = modelMapper.map(bookingPassengerDto,BookingPassenger.class);
            passenger.setBooking(booking);
            passenger.setTrainSeat(coachToBookSeat);
            passenger.setSeatNumber(coachToBookSeat.getSeatNumberToAssign());
            coachToBookSeat.setSeatNumberToAssign(coachToBookSeat.getSeatNumberToAssign()+1);
            coachToBookSeat.setAvailableSeats(coachToBookSeat.getAvailableSeats()-1);

            bookingPassengers.add(passenger);
        }

        booking.setPassengers(bookingPassengers);

        Booking savedBooking = bookingRepository.save(booking);
        this.trainSeatRepository.save(coachToBookSeat);

//        going to create responce

        BookingResponce bookingResponce = new BookingResponce();
        bookingResponce.setBookingId(savedBooking.getId());
        bookingResponce.setPnr(savedBooking.getPnr());
        bookingResponce.setTotalFare(savedBooking.getTotalFare());
        bookingResponce.setBookingStatus(savedBooking.getBookingStatus());
        bookingResponce.setSourceStation(modelMapper.map(sourceStation, StationDTO.class));
        bookingResponce.setDestinationStation(modelMapper.map(destinationStation, StationDTO.class));
        bookingResponce.setJourneyDate(trainSchedule.getRunDate());
        bookingResponce.setPaymentStaus(savedBooking.getPayment().getPaymentStaus());

        bookingResponce.setPassenger(
                savedBooking.getPassengers().stream().map(
                        passenger -> {
                            BookingPassengerDto bookingPassengerDto =  modelMapper.map(passenger,BookingPassengerDto.class);
                            bookingPassengerDto.setCoachId(passenger.getTrainSeat().getId()+"");
                            return bookingPassengerDto;
                        }
                ).toList()
        );

        TrainRoute sourceRoute = trainSchedule.getTrain().getRoutes().stream().filter(route -> route.getStation().getId().equals(sourceStation.getId()) ).findFirst().get();
        bookingResponce.setDepartureTime(sourceRoute.getDepartureTime());
        bookingResponce.setArrivalTime(sourceRoute.getArrivalTime());


        return bookingResponce;
    }
}
