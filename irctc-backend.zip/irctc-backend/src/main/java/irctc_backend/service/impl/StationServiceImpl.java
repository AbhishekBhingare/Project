package irctc_backend.service.impl;

import irctc_backend.dto.PageResponse;
import irctc_backend.dto.StationDTO;
import irctc_backend.entity.Station;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.StationRepository;
import irctc_backend.service.StationSevice;
import org.modelmapper.ModelMapper;
import org.springframework.boot.Banner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class StationServiceImpl implements StationSevice {


    private StationRepository stationRepository;
    private ModelMapper modelMapper;

    public StationServiceImpl(ModelMapper modelMapper, StationRepository stationRepository) {
        this.modelMapper = modelMapper;
        this.stationRepository = stationRepository;
    }

    @Override
    public StationDTO create(StationDTO stationDto) {
        Station station =  modelMapper.map(stationDto, Station.class);
        Station savedStation = stationRepository.save(station);

        return modelMapper.map(savedStation,StationDTO.class);
    }

    @Override
    public PageResponse<StationDTO> listStaion(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.trim().equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size,sort);
        Page<Station> stations = stationRepository.findAll(pageable);
        Page<StationDTO> stationDTOS = stations.map(station -> modelMapper.map(station, StationDTO.class));
        return PageResponse.fromPage(stationDTOS);
    }

    @Override
    public StationDTO getById(Long id) {

        Station station = stationRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Station not found for given id"));

        return modelMapper.map(station,StationDTO.class);
    }

    @Override
    public StationDTO update(Long id, StationDTO stationDTO) {
        Station station = stationRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Staion not found with given id to update"));

//        update
            station.setCode(stationDTO.getCode());
            station.setName(stationDTO.getName());
            station.setCity(stationDTO.getCity());
            station.setState(stationDTO.getState());
            Station updatedStation= stationRepository.save(station);

        return modelMapper.map(updatedStation,StationDTO.class);
    }

    @Override
    public void delete(Long id) {
        Station station = stationRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Station not found to delete"));
        stationRepository.deleteById(id);
    }


}
