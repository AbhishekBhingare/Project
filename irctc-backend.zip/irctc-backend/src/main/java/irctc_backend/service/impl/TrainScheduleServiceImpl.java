package irctc_backend.service.impl;

import irctc_backend.dto.TrainScheduleDto;
import irctc_backend.entity.Train;
import irctc_backend.entity.TrainSchedule;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.TrainRepository;
import irctc_backend.repository.TrainScheduleRepository;
import irctc_backend.service.TrainScheduleService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainScheduleServiceImpl implements TrainScheduleService {

    private TrainScheduleRepository trainScheduleRepository;
    private TrainRepository trainRepository;
    private ModelMapper modelMapper;

    public TrainScheduleServiceImpl(ModelMapper modelMapper, TrainRepository trainRepository, TrainScheduleRepository trainScheduleRepository) {
        this.modelMapper = modelMapper;
        this.trainRepository = trainRepository;
        this.trainScheduleRepository = trainScheduleRepository;
    }

    @Override
    public TrainScheduleDto createSchedule(TrainScheduleDto trainScheduleDto) {
        Train train = trainRepository.findById(trainScheduleDto.getTrainId()).orElseThrow(()-> new ResourceNotFoundException("Train not found for trainSchedule"+trainScheduleDto.getTrainId()));
        TrainSchedule trainSchedule = modelMapper.map(trainScheduleDto, TrainSchedule.class);
        trainSchedule.setTrain(train);
        TrainSchedule savedTrainSchedule = trainScheduleRepository.save(trainSchedule);
        return modelMapper.map(savedTrainSchedule,TrainScheduleDto.class);
    }

    @Override
    public List<TrainScheduleDto> getTrainScheduleByTrainId(Long trainId) {
        Train train = trainRepository.findById(trainId).orElseThrow(()-> new ResourceNotFoundException("train Schedule not found with train id: "+trainId));
        List<TrainSchedule> trainSchedules = trainScheduleRepository.findByTrainId(trainId);

        return trainSchedules.stream().map(trainSchedule -> modelMapper.map(trainSchedule,TrainScheduleDto.class)).toList();
    }

    @Override
    public void deleteTrainSchedule(Long trainScheduleId) {
        TrainSchedule trainSchedule = trainScheduleRepository.findById(trainScheduleId).orElseThrow(()-> new ResourceNotFoundException("train schedule not found with id: "+trainScheduleId));
        trainScheduleRepository.delete(trainSchedule);

    }

    @Override
    public TrainScheduleDto updateTrainSchedule(Long trainScheduleId, TrainScheduleDto trainScheduleDto) {
        TrainSchedule trainSchedule = trainScheduleRepository.findById(trainScheduleId).orElseThrow(()->new ResourceNotFoundException("train schedule not found with id "+trainScheduleId));
        Train train = trainRepository.findById(trainScheduleDto.getTrainId()).orElseThrow(()-> new ResourceNotFoundException("train not found with id: "+trainScheduleDto.getTrainId()));
        trainSchedule.setTrain(train);
        trainSchedule.setAvailableSeats(trainScheduleDto.getAvailableSeats());
        trainSchedule.setRunDate(trainScheduleDto.getRunDate());
        TrainSchedule updatedSchedule = trainScheduleRepository.save(trainSchedule);
        return modelMapper.map(updatedSchedule,TrainScheduleDto.class);

    }
}
