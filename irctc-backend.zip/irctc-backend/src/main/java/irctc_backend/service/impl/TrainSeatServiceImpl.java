package irctc_backend.service.impl;

import irctc_backend.dto.TrainSeatDto;
import irctc_backend.entity.TrainSchedule;
import irctc_backend.entity.TrainSeat;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.TrainScheduleRepository;
import irctc_backend.repository.TrainSeatRepository;
import irctc_backend.service.TrainSeatService;
import lombok.Synchronized;
import org.hibernate.annotations.Synchronize;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TrainSeatServiceImpl implements TrainSeatService {

    private TrainSeatRepository trainSeatRepository;
    private TrainScheduleRepository trainScheduleRepository;
    private ModelMapper modelMapper;

    public TrainSeatServiceImpl(ModelMapper modelMapper, TrainScheduleRepository trainScheduleRepository, TrainSeatRepository trainSeatRepository) {
        this.modelMapper = modelMapper;
        this.trainScheduleRepository = trainScheduleRepository;
        this.trainSeatRepository = trainSeatRepository;
    }


    @Override
    public TrainSeatDto createTrainSeatInto(TrainSeatDto trainSeatDto) {
        TrainSchedule trainSchedule = trainScheduleRepository.findById(trainSeatDto.getTrainScheduleId()).orElseThrow(()->new ResourceNotFoundException("Train schedule not found for train seat No. : "+trainSeatDto.getTrainScheduleId()));
        TrainSeat trainSeat = modelMapper.map(trainSeatDto, TrainSeat.class);
        trainSeat.setTrainSchedule(trainSchedule);
        TrainSeat savedTrainSeat = trainSeatRepository.save(trainSeat);
        return modelMapper.map(savedTrainSeat,TrainSeatDto.class);

    }

    @Override
    public List<TrainSeatDto> getSeatInfoByTrainScheduleId(Long scheduleId) {
        TrainSchedule trainSchedule = trainScheduleRepository.findById(scheduleId).orElseThrow(()-> new ResourceNotFoundException("Train seat not with schedule id : "+scheduleId));
        List<TrainSeat> trainSeat = trainSeatRepository.findByTrainScheduleId(scheduleId);
        return trainSeat.stream().map(trainSeat1 -> modelMapper.map(trainSeat1,TrainSeatDto.class)).toList();

    }

    @Override
    public void deleteTrainSeatInfo(Long seatId) {
        TrainSeat trainSeat = trainSeatRepository.findById(seatId).orElseThrow(()-> new ResourceNotFoundException("Train seat Not found to delete with id: "+seatId));
        trainSeatRepository.delete(trainSeat);

    }

    @Override
    public TrainSeatDto updateTrainSeatInfo(Long seatId, TrainSeatDto trainSeatDto) {
        TrainSeat trainSeat = trainSeatRepository.findById(seatId).orElseThrow(()-> new ResourceNotFoundException("Train Seat Not Found to Delete with id : "+seatId));
        TrainSchedule trainSchedule = trainScheduleRepository.findById(trainSeatDto.getTrainScheduleId()).orElseThrow(()-> new ResourceNotFoundException("Train Schedule not found for train id : "+seatId));
        trainSeat.setTrainSchedule(trainSchedule);
        trainSeat.setCoachType(trainSeatDto.getCoachType());
        trainSeat.setAvailableSeats(trainSeatDto.getAvailableSeats());
        trainSeat.setPrice(trainSeatDto.getPrice());
        trainSeat.setTotalSeats(trainSeatDto.getTotalSeats());
        trainSeat.setSeatNumberToAssign(trainSeatDto.getSeatNumberToAssign());
        trainSeat.setTrainSeatOrder(trainSeatDto.getTrainSeatOrder());
        TrainSeat updatedTrainSeat = trainSeatRepository.save(trainSeat);
        return modelMapper.map(updatedTrainSeat,TrainSeatDto.class);

    }

    @Synchronized
    public List<Integer> bookSeat(int seatToBook, Long seatId){
        TrainSeat trainSeat = trainSeatRepository.findById(seatId).orElseThrow(()->new ResourceNotFoundException("train seat not found wi id : "+seatId));
        if(trainSeat.isSeatAvailable(seatToBook)){
            trainSeat.setAvailableSeats(trainSeat.getAvailableSeats()-seatToBook);
            List<Integer> bookedSeats = new ArrayList<>();
            for(int i=1; i<=seatToBook; i++){
                bookedSeats.add(trainSeat.getSeatNumberToAssign());
                trainSeat.setSeatNumberToAssign((trainSeat.getSeatNumberToAssign()) + 1);
            }
            trainSeatRepository.save(trainSeat);
            return bookedSeats;
        }else {
            throw new IllegalStateException("No seat Available in this coach");
        }

    }


}