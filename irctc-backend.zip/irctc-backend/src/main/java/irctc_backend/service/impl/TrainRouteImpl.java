package irctc_backend.service.impl;

import irctc_backend.dto.TrainDTO;
import irctc_backend.dto.TrainRouteDto;
import irctc_backend.entity.Station;
import irctc_backend.entity.Train;
import irctc_backend.entity.TrainRoute;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.StationRepository;
import irctc_backend.repository.TrainRepository;
import irctc_backend.repository.TrainRouteRepository;
import irctc_backend.service.TrainRouteService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainRouteImpl implements TrainRouteService {

    private TrainRepository trainRepository;
    private StationRepository stationRepository;
    private TrainRouteRepository trainRouteRepository;
    private ModelMapper modelMapper;

    public TrainRouteImpl(ModelMapper modelMapper, StationRepository stationRepository, TrainRepository trainRepository, TrainRouteRepository trainRouteRepository) {
        this.modelMapper = modelMapper;
        this.stationRepository = stationRepository;
        this.trainRepository = trainRepository;
        this.trainRouteRepository = trainRouteRepository;
    }

    @Override
    public TrainRouteDto addRoute(TrainRouteDto trainRouteDto) {
        Train train = this.trainRepository.findById(trainRouteDto.getTrain().getId()).orElseThrow(()-> new ResourceNotFoundException("train not found with train id: "+trainRouteDto.getTrain().getId()));
        Station station = this.stationRepository.findById(trainRouteDto.getStation().getId()).orElseThrow(()-> new ResourceNotFoundException("Station not found wit station id: "+trainRouteDto.getStation().getId()));

//        convert DTO to entity
        TrainRoute trainRoute = modelMapper.map(trainRouteDto, TrainRoute.class);
        trainRoute.setTrain(train);
        trainRoute.setStation(station);
//        save the TrainRoute entity
        TrainRoute savedTrainRoute = trainRouteRepository.save(trainRoute);
//      convert saved entity back to DTO
        TrainRouteDto trainRouteDto1 = modelMapper.map(savedTrainRoute,TrainRouteDto.class);

        return  trainRouteDto1;
    }

    @Override
    public List<TrainRouteDto> getRoutesByTrain(Long trainId) {
        Train train = trainRepository.findById(trainId).orElseThrow(()-> new ResourceNotFoundException("Train not found with train id: "+trainId));
        List<TrainRoute> trainRoute = this.trainRouteRepository.findByTrainId(trainId);
        List<TrainRouteDto> trainRouteDtos = trainRoute.stream().map(trainRoute1-> modelMapper.map(trainRoute1,TrainRouteDto.class)).toList();
        return trainRouteDtos;
    }

    @Override
    public TrainRouteDto update(Long id, TrainRouteDto trainRouteDto) {
        TrainRoute existingRoute = trainRouteRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("TrainRoute not foun with trainroute id: "+id));
        Station station = stationRepository.findById(trainRouteDto.getStation().getId()).orElseThrow(()-> new ResourceNotFoundException("Station not found with id: "+trainRouteDto.getStation().getId()));
        Train train = trainRepository.findById(trainRouteDto.getStation().getId()).orElseThrow(()->new ResourceNotFoundException("Train not found with id: "+trainRouteDto.getTrain().getId()));
//        update existing route with new values
        existingRoute.setStation(station);
        existingRoute.setTrain(train);
        existingRoute.setStationOrder(trainRouteDto.getStationOrder());
        existingRoute.setArrivalTime(trainRouteDto.getArrivalTime());
        existingRoute.setDepartureTime(trainRouteDto.getDepartureTime());
        existingRoute.setHaltMinutes(trainRouteDto.getHaltMinutes());
        existingRoute.setDistanceFromSource(trainRouteDto.getDistanceFromSource());

        TrainRoute updatedRoute = trainRouteRepository.save(existingRoute);
        TrainRouteDto updatedRouteDto1 = modelMapper.map(updatedRoute,TrainRouteDto.class);
        return updatedRouteDto1;
    }

    @Override
    public void deleteRoute(Long id) {
            TrainRoute trainRoute = trainRouteRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("trainRoute not found with id: "+id));
            trainRouteRepository.delete(trainRoute);
    }
}
