package irctc_backend.service;

import irctc_backend.dto.UserDto;

public interface UserService {

    public UserDto registerUser(UserDto userDto);
}
