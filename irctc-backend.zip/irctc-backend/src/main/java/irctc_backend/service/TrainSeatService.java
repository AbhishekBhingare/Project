package irctc_backend.service;

import irctc_backend.dto.TrainSeatDto;

import java.util.List;

public interface TrainSeatService {

    TrainSeatDto createTrainSeatInto(TrainSeatDto trainSeatDto);
    List<TrainSeatDto> getSeatInfoByTrainScheduleId(Long scheduleId);
    void deleteTrainSeatInfo(Long seatId);
    TrainSeatDto updateTrainSeatInfo(Long seatId, TrainSeatDto trainSeatDto);
    public List<Integer> bookSeat(int seatToBook, Long seatId);
}
