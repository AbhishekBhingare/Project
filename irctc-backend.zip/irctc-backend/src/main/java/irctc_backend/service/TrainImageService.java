package irctc_backend.service;

import irctc_backend.config.AppConstant;
import irctc_backend.dto.TrainImageDataWithResource;
import irctc_backend.dto.TrainImageResponce;
import irctc_backend.entity.Train;
import irctc_backend.entity.TrainImage;
import irctc_backend.exceptions.ResourceNotFoundException;
import irctc_backend.repository.TrainImageRepository;
import irctc_backend.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class TrainImageService {

    @Value("${train.image.folder.path}")
    private String folderPath;

    @Autowired
    private TrainImageRepository trainImageRepository;
    @Autowired
    private TrainRepository trainRepository;

//    logic to upload image
    public TrainImageResponce upload(MultipartFile file, Long trainNo) throws IOException {

        Train train = trainRepository.findById(trainNo).orElseThrow(()-> new ResourceNotFoundException("Train not found"));

//        checking and creating folder
        if(!Files.exists(Paths.get(folderPath))){
            System.out.println("creating folder");
            Files.createDirectories(Paths.get(folderPath));
        }


        String fullFilePath = folderPath+ UUID.randomUUID()+"_"+file.getOriginalFilename();
        Files.copy(file.getInputStream(), Paths.get(fullFilePath), StandardCopyOption.REPLACE_EXISTING);
        System.out.println("file uploaded");

        TrainImage trainImage = new TrainImage();
        trainImage.setFileName(fullFilePath);
        trainImage.setFileType(file.getContentType());
        trainImage.setSize(file.getSize());

        trainImage.setTrain(train);
        train.setTrainImage(trainImage);

        Train savedTrain = trainRepository.save(train);

        return TrainImageResponce.from(savedTrain.getTrainImage(), AppConstant.BASE_URL,trainNo);

    }

//    logic to return image to user
    public TrainImageDataWithResource loadImageByTrainNo(Long  trainNo) throws MalformedURLException {

        Train train = trainRepository.findById(trainNo).orElseThrow(()->new ResourceNotFoundException("Train not found"));
        TrainImage trainImage = train.getTrainImage();
        if(trainImage==null){
            throw new ResourceNotFoundException("Image not found");
        }

        Path path = Paths.get(trainImage.getFileName());
        System.out.println("printing path trainImage.getFileName "+path);
        if(!Files.exists(path)){
            throw new ResourceNotFoundException("image not found");
        }
        System.out.println("printing return path.toUri() from load image by train no "+path.toUri());
        Resource resource = new UrlResource(path.toUri());
        TrainImageDataWithResource trainImageDataWithResource = new TrainImageDataWithResource(trainImage,resource);
        return trainImageDataWithResource;

    }

}
