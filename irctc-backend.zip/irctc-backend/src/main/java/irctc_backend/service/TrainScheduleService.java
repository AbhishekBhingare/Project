package irctc_backend.service;

import irctc_backend.dto.TrainScheduleDto;
import irctc_backend.entity.TrainSchedule;

import java.util.List;

public interface TrainScheduleService {

    TrainScheduleDto createSchedule(TrainScheduleDto trainScheduleDto);
    List<TrainScheduleDto> getTrainScheduleByTrainId(Long tranId);
    void deleteTrainSchedule(Long trainScheduleId);
    TrainScheduleDto updateTrainSchedule(Long trainScheduleId, TrainScheduleDto trainScheduleDto);



}
