package irctc_backend.service;

import irctc_backend.dto.TrainDTO;
import irctc_backend.dto.TrainRouteDto;

import java.util.List;

public interface TrainRouteService {

//    add train route
    TrainRouteDto addRoute(TrainRouteDto trainRouteDto);

//    get train route by train id
    List<TrainRouteDto> getRoutesByTrain(Long id);

//    update Train route
    TrainRouteDto update(Long id, TrainRouteDto trainRouteDto);

//    delete train route
    void deleteRoute(Long id);

}
