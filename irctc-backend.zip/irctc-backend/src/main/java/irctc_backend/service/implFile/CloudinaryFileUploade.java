package irctc_backend.service.implFile;

import irctc_backend.entity.ImageMetaData;
import irctc_backend.service.FileUploadService;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public class CloudinaryFileUploade implements FileUploadService {
    @Override
    public ImageMetaData upload(MultipartFile file) throws IOException {
//        logic to upload file to cloudinary
        return null;
    }
}
