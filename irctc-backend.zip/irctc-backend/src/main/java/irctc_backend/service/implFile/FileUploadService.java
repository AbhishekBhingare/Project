package irctc_backend.service.implFile;

import irctc_backend.entity.ImageMetaData;
import irctc_backend.helper.Helper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileUploadService implements irctc_backend.service.FileUploadService {


    @Value("${file.upload.folder}")
    private String folder;

    @Override
    public ImageMetaData upload(MultipartFile file) throws IOException {

        String origianlFileName =  file.getOriginalFilename();
        System.out.println("File name is : "+origianlFileName);

        InputStream inputStream = file.getInputStream();

//        String fileNameWithPath= folder+ UUID.randomUUID()+"_"+origianlFileName;
        String fileNameWithPath = Helper.getFileName(folder,origianlFileName);
        System.out.println(fileNameWithPath);
        if(!Files.exists(Paths.get(folder))){
            System.out.println("Creating Folder");
            Files.createDirectories(Paths.get(folder));
        }

        Files.copy(file.getInputStream(),Paths.get(fileNameWithPath), StandardCopyOption.REPLACE_EXISTING);

        ImageMetaData imageMetaData = new ImageMetaData();

        imageMetaData.setFileId(UUID.randomUUID().toString());
        imageMetaData.setFileName(fileNameWithPath);
        imageMetaData.setFileSize(file.getSize());
        imageMetaData.setContentType(file.getContentType());

        return imageMetaData;
    }
}
