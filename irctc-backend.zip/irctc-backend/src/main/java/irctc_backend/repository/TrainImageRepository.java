package irctc_backend.repository;

import irctc_backend.entity.TrainImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainImageRepository extends JpaRepository<TrainImage,Long> {

}
