package irctc_backend.repository;

import irctc_backend.entity.TrainSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.swing.text.html.Option;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TrainScheduleRepository extends JpaRepository<TrainSchedule,Long> {

    @Query("SELECT ts FROM TrainSchedule ts WHERE ts.train.id = ?1")
    List<TrainSchedule> findByTrainId(Long trainId);

    @Query("SELECT ts FROM TrainSchedule ts WHERE ts.train.id = ?1 AND ts.runDate = ?2")
    Optional<TrainSchedule> findByTrainIdAndRunDate(Long trainId, LocalDate runDate);

}
