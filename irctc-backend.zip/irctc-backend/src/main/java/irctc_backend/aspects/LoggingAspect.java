package irctc_backend.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Around("execution(* irctc_backend.service.impl.*.*(..))")
    public Object logBeforeMethod(ProceedingJoinPoint joinPoint) throws Throwable {

        long startTime = System.currentTimeMillis();
        logger.info("Before method execution {}", joinPoint.getSignature().getName());

        Object result = joinPoint.proceed();
        long endTime = System.currentTimeMillis();
        logger.info("Time taken {} ms ",endTime-startTime);
        logger.info("After method execution {}", joinPoint.getSignature().getName());
        return result;
    }

    /*
    @Before() - before method execution
    @After() - after method finish
    @AfterReturning() - after successful return
    @AfterThrowing - aftere thrworing exception
    @Around() - before and after
    */

}
