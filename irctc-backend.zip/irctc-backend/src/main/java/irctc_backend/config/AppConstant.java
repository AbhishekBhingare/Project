package irctc_backend.config;

public class AppConstant {
    public static String BASE_URL = "http://localhost:8080";
    public static final String DEFAULT_PAGE = "0";
    public static final String DEFAULT_PAGE_SIZE="10";
}
