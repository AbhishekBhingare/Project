package irctc_backend.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "IRCTC Clonw API By Abhishek",
                version = "1.0.0",
                description = "API Documentation for IRCTC Project",
                termsOfService = "http://www.irctc.co.in/term-of-service",
                contact = @Contact(
                        name = "IRCTC Support",
                        url = "http://irctc.co.in/contact-us",
                        email = "abhishebhingare100@gmail.com"
                )

        )
,
        security = @SecurityRequirement(name = "bearerAuth")

)
@SecurityScheme(
        name = "bearerAuth",
        type = SecuritySchemeType.HTTP,
        scheme = "bearer",
        bearerFormat = "JWT"
)



public class OpenApiConfig {
//    @Bean
//    public OpenAPI openAPI(){
//        return new OpenAPI()
//                .info(
//                        new Info()
//                                .title("IRCTC API")
//                                .version("1.0.0")
//                                .description("API documentation for IRCTC Project")
//                                .termsOfService("https://www.irctc.co.in/term-of-service")
//                                .contact(new io.swagger.v3.oas.models.info.Contact()
//                                        .name("IRCTC Project")
//                                        .url("https://www.irctc.co.in/contact-us")
//                                        .email("abhishekbhingare100@gmail.com"))
//
//                );
//    }
}
