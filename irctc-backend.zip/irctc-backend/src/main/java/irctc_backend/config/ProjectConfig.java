package irctc_backend.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import irctc_backend.interceptors.MyCustomInterceptor;
import irctc_backend.interceptors.TimeLoggerInterceptor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class ProjectConfig implements WebMvcConfigurer {

    @Autowired
    private MyCustomInterceptor myCustomInterceptor;
    @Autowired
    private TimeLoggerInterceptor timeLoggerInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(timeLoggerInterceptor)
                .addPathPatterns("/trains/**", "station/**")
                .excludePathPatterns("/trains/list");
    }


    @Bean
    public ModelMapper modelMapper(){
        return new ModelMapper();
    }



}


