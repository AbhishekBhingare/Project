package irctc_backend.config.security;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    private JwtHelper jwtHelper;
    private UserDetailsService userDetailsService;

    public JwtAuthenticationFilter(JwtHelper jwtHelper, UserDetailsService userDetailsService) {
        this.jwtHelper = jwtHelper;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String authorizationHeader = request.getHeader("Authorization");
        logger.trace("Request to the jwt Filter : {}", authorizationHeader);
        String username = null;
        String token = null;

        if(authorizationHeader!= null && authorizationHeader.startsWith("Bearer ")){

            try{
                token  = authorizationHeader.substring(7); // remove bearer and store only token
                username = jwtHelper.getUserNameFromToken(token);
                logger.trace("user name : {}",username);
                logger.info("Token : {}",token);

                if(username!=null && SecurityContextHolder.getContext().getAuthentication() == null){
                    UserDetails userDetails = userDetailsService.loadUserByUsername(username); // userdetail come from database

                    if(jwtHelper.isTokenValid(token,userDetails)){
                        UsernamePasswordAuthenticationToken authentication =
                                new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());

                        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                        SecurityContextHolder.getContext().setAuthentication(authentication);
                        logger.trace("Authentication is set in the Security Context");
                    }

                }


            }catch (IllegalArgumentException ex){
                logger.error("Unable to get jwt token");
                ex.printStackTrace();
            }catch (ExpiredJwtException ex){
                logger.error("JWT token has expired");
                ex.printStackTrace();
            }catch (MalformedJwtException ex){
                logger.error("Invalid JWT token");
                ex.printStackTrace();
            }


            catch (Exception e){
                System.out.println(e);
                e.printStackTrace();
            }


        }else {
            System.out.println("Invalid authorization Header");
        }

        filterChain.doFilter(request,response);

    }
}
