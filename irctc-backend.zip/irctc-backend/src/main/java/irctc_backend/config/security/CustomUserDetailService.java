package irctc_backend.config.security;

import irctc_backend.entity.User;
import irctc_backend.repository.UserRepo;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailService implements UserDetailsService
{

    private UserRepo userRepo;

    public CustomUserDetailService(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = userRepo.findByEmail(username).orElseThrow(()-> new UsernameNotFoundException("user not found with :"+username));
        CustomUserDetail customUserDetail = new CustomUserDetail(user);


//        UserDetails user = User.builder()
//                .username("user")
//                .password("{noop}user123")
//                .roles("USER")
//                .build();
//
//        if(user.getUsername().equals(username)){
//            return user;
//        }else {
//            throw new UsernameNotFoundException("User not found with username : "+username);
//        }
        return customUserDetail;

    }
}
