package irctc_backend.interceptors;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class MyCustomInterceptor implements HandlerInterceptor {


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {


        System.out.println("Intercepting Request");
        System.out.println("Prehandle Request");
        System.out.println(request.getRequestURI());
        System.out.println(request.getRequestURL());

        System.out.println("----------------");

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

        System.out.println("Post handling the request");
        System.out.println(request.getRequestURI());
        System.out.println(request.getRequestURL());
        System.out.println("--------------------");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

        System.out.println("Request processing complete" );
        System.out.println(request.getRequestURI());
        System.out.println(request.getRequestURL());

    }
}
