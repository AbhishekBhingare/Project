package irctc_backend.helper;

import java.util.UUID;

public class Helper {

    public static String getFileName(String folder, String originalFileName){
//        logic to generate file name
        return folder+ UUID.randomUUID()+"_"+originalFileName;
    }
}
