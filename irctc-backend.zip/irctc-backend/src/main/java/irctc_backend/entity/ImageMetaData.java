package irctc_backend.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;


public class ImageMetaData {

    private String fileName;
    private String fileId;
    private String contentType;
    private long fileSize;
    private LocalDateTime uploadedAt;


    public ImageMetaData() {
    }

    public ImageMetaData(String contentType, String fileId, String fileName, long fileSize, LocalDateTime uploadedAt) {
        this.contentType = contentType;
        this.fileId = fileId;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.uploadedAt = uploadedAt;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public LocalDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(LocalDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }
}
