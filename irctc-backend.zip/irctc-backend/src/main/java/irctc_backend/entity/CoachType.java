package irctc_backend.entity;

public enum CoachType {
    AC,SLEEPER,GENERAL
}
