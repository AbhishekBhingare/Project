package irctc_backend.entity;

public enum PaymentStaus {
    PENDING,PAID,FAILED,REFUNDED,NOT_PAID
}
