package irctc_backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "train_seats")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TrainSeat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "train_schedule_id")
    private TrainSchedule trainSchedule;

    @Enumerated(EnumType.STRING)
    private CoachType coachType;

    private Integer totalSeats;
    private Integer availableSeats;
    private Double price;

    private Integer trainSeatOrder;

    private Integer seatNumberToAssign;

    public boolean isCoachFull(){
        return availableSeats<=0;
    }

    public boolean isSeatAvailable(int seatToBook){
        return seatToBook <= availableSeats;
    }




}
