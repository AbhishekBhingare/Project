package irctc_backend.entity;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED
}
