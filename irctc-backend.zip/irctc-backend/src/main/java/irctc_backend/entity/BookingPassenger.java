package irctc_backend.entity;


import jakarta.persistence.*;
import lombok.*;

import java.lang.reflect.GenericArrayType;
import java.util.List;

@Entity
@Table(name = "Booking_passenger")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BookingPassenger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

    private String name;
    private Integer age;
    private String gender;

    @ManyToOne
    private TrainSeat trainSeat;

    private Integer seatNumber;

    
}
